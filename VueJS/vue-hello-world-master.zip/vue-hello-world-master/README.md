# Vue.js on Render

This is a minimal Vue.js project bootstrapped with [vue-cli](https://cli.vuejs.org/guide/creating-a-project.html).

The sample app is deployed on Render at https://vue.onrender.com.

## Deployment

Follow the guide at https://render.com/docs/deploy-vue-js.
